beam_size=$1
gamma=$2

python ../translate_beam.py --data ../data/en-fr/prepared --dicts ../data/en-fr/prepared --checkpoint-path ./checkpoint_best_03.pt --beam-size $1 --gamma $2 --output ./t2_$1_$2.t --cuda True

cd ../

bash ./scripts/postprocess.sh ./question4/t2_$1_$2.t ./question4/t2_$1_$2_post.t en