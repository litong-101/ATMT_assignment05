bash auto_translate_beam_only_gamma.sh 12 0.5
bash auto_translate_beam.sh 12 1
bash auto_translate_beam_only_gamma.sh 12 2
bash auto_translate_beam_only_gamma.sh 12 3
bash auto_translate_beam_only_gamma.sh 12 5


