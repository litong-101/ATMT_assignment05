import matplotlib.pyplot as plt
import numpy as np

# Create some mock data
t = [3,5,10,12,15,20,25]
bleu = [19.1,20.2,22.2,22.2,22.1,21.8,21.4]
bp = [1,1,1,1,0.949,0.864,0.792]

fig, ax1 = plt.subplots()

color = 'tab:red'
ax1.set_xlabel('beam size')


ax1.set_ylabel('bleu', color=color)
ax1.plot(t, bleu, color=color)
ax1.tick_params(axis='y', labelcolor=color)

ax2 = ax1.twinx()

color = 'tab:blue'
ax2.set_ylabel('bp', color=color)
ax2.plot(t, bp, color=color)
ax2.tick_params(axis='y', labelcolor=color)

fig.tight_layout()
plt.show()