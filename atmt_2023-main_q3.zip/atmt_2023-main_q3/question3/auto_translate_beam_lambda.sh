beam_size=$1
lambda_=$2

python ../translate_beam.py --data ../data/en-fr/prepared --dicts ../data/en-fr/prepared --checkpoint-path ./checkpoint_best_03.pt --beam-size $1 --output ./t_$1.t --lambda_ $2 --cuda True

cd ../

bash ./scripts/postprocess.sh ./question3/t_$1.t ./question3/t_$1_post.t en

cd ./question3

cat t_$1_post.t | sacrebleu ../data/en-fr/raw/test.en
